-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 06 oct. 2026 à 15:19
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e_gaming_baptiste_giroud_lantez`
--

-- --------------------------------------------------------

--
-- Structure de la table `carte`
--

CREATE TABLE `carte` (
  `id_carte` smallint(5) UNSIGNED NOT NULL,
  `nom` varchar(40) NOT NULL,
  `rareter` varchar(40) DEFAULT NULL,
  `attaque` varchar(60) NOT NULL,
  `degat` decimal(65,0) UNSIGNED DEFAULT NULL,
  `hp` decimal(65,0) UNSIGNED DEFAULT NULL,
  `image_url` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `carte`
--

INSERT INTO `carte` (`id_carte`, `nom`, `rareter`, `attaque`, `degat`, `hp`, `image_url`) VALUES
(3, 'Punisher', 'commun', 'Drama avec Asterion', 40, 90, 'une image'),
(4, 'Asterion', 'commun', 'Le Minotaure', 30, 100, 'une image'),
(5, 'Hellydia', 'commun', 'Faux drama', 40, 90, 'une image'),
(6, 'Kim Jung Un', 'epique', 'T’as nettoyer mon portrait', 60, 120, 'une image'),
(7, 'Ad Laurent', 'epique', 'pupuce !', 80, 110, 'une image'),
(8, 'Jordan Bardella', 'legendaire', 'Pour les français', 100, 200, 'image_url'),
(9, 'CJ', 'secret', 'Oh shit and we go again', 130, 290, 'une image');

-- --------------------------------------------------------

--
-- Structure de la table `fonction`
--

CREATE TABLE `fonction` (
  `id_fonction` smallint(6) NOT NULL,
  `nom_fonction` varchar(40) NOT NULL,
  `description_fonction` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `fonction`
--

INSERT INTO `fonction` (`id_fonction`, `nom_fonction`, `description_fonction`) VALUES
(1, 'attaque', 'attaquer un enemi pour lui faire perdre de la vie'),
(2, 'HP', 'Vie de la carte');

-- --------------------------------------------------------

--
-- Structure de la table `inventaire`
--

CREATE TABLE `inventaire` (
  `id_joueur` smallint(5) UNSIGNED NOT NULL,
  `id_carte` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `inventaire`
--

INSERT INTO `inventaire` (`id_joueur`, `id_carte`) VALUES
(1, 3),
(2, 4),
(3, 5),
(4, 6),
(5, 7),
(2, 8),
(2, 9);

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

CREATE TABLE `joueur` (
  `id_joueur` smallint(5) UNSIGNED NOT NULL,
  `pseudo` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `points` decimal(7,2) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `joueur`
--

INSERT INTO `joueur` (`id_joueur`, `pseudo`, `email`, `points`) VALUES
(1, 'DarkSasuke', 'sasuke@email.com', 150.00),
(2, 'GamerPro', 'pro@email.com', 20.00),
(3, 'Noob', 'noob@golmon.com', 0.00),
(4, 'Jean', 'jean@email.com', 40.00),
(5, 'cle usb', 'cleusb@email.com', 15.00);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `carte`
--
ALTER TABLE `carte`
  ADD PRIMARY KEY (`id_carte`);

--
-- Index pour la table `fonction`
--
ALTER TABLE `fonction`
  ADD PRIMARY KEY (`id_fonction`);

--
-- Index pour la table `inventaire`
--
ALTER TABLE `inventaire`
  ADD KEY `fk_id_joueur` (`id_joueur`),
  ADD KEY `fk_id_carte` (`id_carte`);

--
-- Index pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD PRIMARY KEY (`id_joueur`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `carte`
--
ALTER TABLE `carte`
  MODIFY `id_carte` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `fonction`
--
ALTER TABLE `fonction`
  MODIFY `id_fonction` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `inventaire`
--
ALTER TABLE `inventaire`
  MODIFY `id_joueur` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `joueur`
--
ALTER TABLE `joueur`
  MODIFY `id_joueur` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `inventaire`
--
ALTER TABLE `inventaire`
  ADD CONSTRAINT `fk_id_carte` FOREIGN KEY (`id_carte`) REFERENCES `carte` (`id_carte`),
  ADD CONSTRAINT `fk_id_joueur` FOREIGN KEY (`id_joueur`) REFERENCES `joueur` (`id_joueur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
